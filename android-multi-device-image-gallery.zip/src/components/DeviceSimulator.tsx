/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { 
  Smartphone, 
  Tablet, 
  Monitor, 
  Wifi, 
  Battery, 
  Signal, 
  Camera, 
  RotateCw, 
  ChevronRight,
  Sparkles,
  Info
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { DeviceType } from "../types";

interface DeviceSimulatorProps {
  children: React.ReactNode;
  activeDevice: DeviceType;
  setActiveDevice: (device: DeviceType) => void;
}

export default function DeviceSimulator({
  children,
  activeDevice,
  setActiveDevice,
}: DeviceSimulatorProps) {
  const [time, setTime] = useState<string>("");
  const [batteryLevel, setBatteryLevel] = useState<number>(85);
  const [isCharging, setIsCharging] = useState<boolean>(true);
  const [tabletOrientation, setTabletOrientation] = useState<"portrait" | "landscape">("landscape");

  // Keep simulated time updated
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      let hours = now.getHours();
      const minutes = now.getMinutes().toString().padStart(2, "0");
      const ampm = hours >= 12 ? "PM" : "AM";
      hours = hours % 12 || 12;
      setTime(`${hours}:${minutes} ${ampm}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 10000);
    return () => clearInterval(interval);
  }, []);

  // Update mock battery behavior over time
  useEffect(() => {
    const interval = setInterval(() => {
      setBatteryLevel((prev) => {
        if (prev <= 10) {
          setIsCharging(true);
          return 11;
        }
        if (prev >= 100) {
          setIsCharging(false);
          return 99;
        }
        return isCharging ? prev + 1 : prev - 1;
      });
    }, 45000);
    return () => clearInterval(interval);
  }, [isCharging]);

  return (
    <div className="w-full flex flex-col min-h-screen bg-[#050505] text-[#E0D8D0] font-sans" id="device-simulator-root">
      {/* Simulation Header controls */}
      <header className="w-full bg-[#050505] border-b border-white/10 py-3.5 px-6 flex flex-col md:flex-row items-center justify-between gap-4 z-40 select-none">
        <div className="flex items-center gap-3">
          <div className="text-2xl font-serif italic text-[#E0D8D0] pr-1.5 border-r border-white/10">L.</div>
          <div>
            <h1 className="text-sm font-serif italic tracking-wide text-[#E0D8D0] flex items-center gap-2">
              Collections Previewer
              <span className="text-[9px] font-sans font-normal uppercase tracking-widest bg-white/5 text-white/60 px-2 py-0.5 rounded-full border border-white/10">
                Adaptive Sim v2.4
              </span>
            </h1>
            <p className="text-[10px] uppercase tracking-[0.18em] text-white/40 mt-0.5">Curated Media • Responsive Canvas Layout</p>
          </div>
        </div>

        {/* Device Switcher */}
        <div className="flex items-center bg-white/5 border border-white/10 rounded-full p-1 gap-1">
          <button
            id="btn-device-phone"
            onClick={() => setActiveDevice("phone")}
            className={`flex items-center gap-1.5 px-4 py-1.5 text-[10px] font-semibold uppercase tracking-wider rounded-full cursor-pointer transition-all duration-350 ${
              activeDevice === "phone"
                ? "bg-[#E0D8D0] text-black shadow-md"
                : "text-white/60 hover:text-white hover:bg-white/5"
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            Mobile
          </button>
          
          <button
            id="btn-device-tablet"
            onClick={() => setActiveDevice("tablet")}
            className={`flex items-center gap-1.5 px-4 py-1.5 text-[10px] font-semibold uppercase tracking-wider rounded-full cursor-pointer transition-all duration-350 ${
              activeDevice === "tablet"
                ? "bg-[#E0D8D0] text-black shadow-md"
                : "text-white/60 hover:text-white hover:bg-white/5"
            }`}
          >
            <Tablet className="w-3.5 h-3.5" />
            Tablet
          </button>

          <button
            id="btn-device-desktop"
            onClick={() => setActiveDevice("desktop")}
            className={`flex items-center gap-1.5 px-4 py-1.5 text-[10px] font-semibold uppercase tracking-wider rounded-full cursor-pointer transition-all duration-350 ${
              activeDevice === "desktop"
                ? "bg-[#E0D8D0] text-black shadow-md"
                : "text-white/60 hover:text-white hover:bg-white/5"
            }`}
          >
            <Monitor className="w-3.5 h-3.5" />
            Web Canvas
          </button>
        </div>

        {/* Extra option for orientation */}
        <div className="flex items-center gap-3">
          {activeDevice === "tablet" && (
            <button
               id="btn-rotate-tablet"
               onClick={() => setTabletOrientation(prev => prev === "landscape" ? "portrait" : "landscape")}
               className="flex items-center gap-1.5 bg-white/5 border border-white/10 hover:bg-white/10 px-4 py-1.5 rounded-full text-[10px] font-semibold uppercase tracking-wider text-[#E0D8D0] cursor-pointer transition-all active:scale-95 animate-fade-in"
            >
              <RotateCw className="w-3.5 h-3.5 text-white/60" />
              <span>Rotate ({tabletOrientation})</span>
            </button>
          )}
          
          <div className="hidden lg:flex items-center gap-1.5 text-[10px] font-mono tracking-wider uppercase text-white/40 bg-white/5 px-3 py-1.5 rounded-full border border-white/5">
            <Info className="w-3 h-3 text-white/40" />
            <span>Design: Sophisticated Dark</span>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 flex items-center justify-center p-4 md:p-8 bg-[#020202] overflow-hidden relative" id="simulator-canvas">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:3.5rem_3.5rem] pointer-events-none" />

        <AnimatePresence mode="wait">
          {activeDevice === "phone" && (
            <motion.div
              key="phone-device"
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: -15 }}
              transition={{ type: "spring", stiffness: 300, damping: 25 }}
              className="relative mx-auto my-auto w-[390px] h-[780px] bg-[#050505] rounded-[48px] p-3 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.9)] border-[4px] border-white/10 flex flex-col overflow-hidden group select-none"
              id="phone-frame-container"
            >
              {/* Phone Physical elements */}
              <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-6 bg-[#050505] border-b border-x border-white/10 rounded-b-2xl z-50 flex items-center justify-center gap-2">
                {/* Simulated Camera lens */}
                <div className="w-2.5 h-2.5 bg-neutral-900 rounded-full border border-white/10 flex items-center justify-center">
                  <div className="w-1 h-1 bg-neutral-950 rounded-full" />
                </div>
                {/* Speaker mesh slit */}
                <div className="w-10 h-0.5 bg-white/10 rounded-full" />
              </div>
              
              {/* Dynamic volume / lock buttons on side for looks */}
              <div className="absolute -left-[4px] top-32 w-1 h-12 bg-white/10 rounded-r-md" />
              <div className="absolute -left-[4px] top-48 w-1 h-16 bg-white/10 rounded-r-md" />
              <div className="absolute -right-[4px] top-40 w-1 h-14 bg-white/10 rounded-l-md" />

              {/* Status Bar */}
              <div className="w-full h-8 pt-1.5 px-6 flex justify-between items-center text-[10px] font-mono uppercase tracking-wider text-white/50 z-40 bg-[#050505] select-none">
                <span>{time.replace(/ AM| PM/, "")}</span>
                <div className="flex items-center gap-1.5">
                  <Signal className="w-3 h-3 text-white/40" />
                  <Wifi className="w-3 h-3 text-white/40" />
                  <div className="flex items-center gap-1">
                    <span className="text-[9px] text-white/30">{batteryLevel}%</span>
                    <Battery className={`w-3.5 h-3.5 ${isCharging ? "text-[#E0D8D0]" : "text-white/40"}`} />
                  </div>
                </div>
              </div>

              {/* Inside App Space */}
              <div className="flex-1 w-full bg-[#050505] rounded-[32px] overflow-hidden flex flex-col relative select-text border border-white/5">

                {children}

                {/* Simulated Android Gestures bar at bottom of phone */}
                <div className="w-full h-6 bg-slate-950 flex items-center justify-center pb-1 z-35 select-none">
                  <div className="w-32 h-1 bg-white/40 rounded-full" />
                </div>
              </div>
            </motion.div>
          )}

          {activeDevice === "tablet" && (
            <motion.div
              key={`tablet-device-${tabletOrientation}`}
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: -15 }}
              transition={{ type: "spring", stiffness: 300, damping: 25 }}
              className={`relative mx-auto my-auto bg-[#050505] rounded-[40px] p-3 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.9)] border-[4px] border-white/10 flex flex-col overflow-hidden select-none ${
                tabletOrientation === "landscape" ? "w-[920px] h-[610px]" : "w-[610px] h-[920px]"
              }`}
              id="tablet-frame-container"
            >
              {/* Tablet Camera punch */}
              <div className={`absolute w-2.5 h-2.5 bg-neutral-900 rounded-full border border-white/10 flex items-center justify-center z-50 ${
                tabletOrientation === "landscape" ? "top-1/2 left-3 -translate-y-1/2" : "top-3 left-1/2 -translate-x-1/2"
              }`}>
                <div className="w-1 h-1 bg-neutral-950 rounded-full" />
              </div>

              {/* Status Bar */}
              <div className="w-full h-8 pt-1.5 px-6 flex justify-between items-center text-[10px] font-mono uppercase tracking-wider text-white/50 z-40 bg-[#050505] select-none">
                <div className="flex items-center gap-1.5">
                  <span className="bg-white/5 text-[9px] text-white/60 uppercase tracking-widest px-2 py-0.5 rounded-full border border-white/5 max-w-28 truncate">
                    Tablet Mode
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span>{time}</span>
                  <div className="w-[1px] h-3 bg-white/10" />
                  <Signal className="w-3 h-3 text-white/40" />
                  <Wifi className="w-3 h-3 text-white/40" />
                  <div className="flex items-center gap-1">
                    <span className="text-[9px] text-white/30">{batteryLevel}%</span>
                    <Battery className={`w-3.5 h-3.5 ${isCharging ? "text-[#E0D8D0]" : "text-white/40"}`} />
                  </div>
                </div>
              </div>

              {/* Inside App Space */}
              <div className="flex-1 w-full bg-[#050505] rounded-[24px] overflow-hidden flex flex-col relative select-text border border-white/5">
                {children}

                {/* Simulated Tablet gestures bar */}
                <div className="w-full h-5 bg-[#050505] flex items-center justify-center pb-1 z-35 select-none animate-pulse">
                  <div className="w-40 h-0.5 bg-white/20 rounded-full" />
                </div>
              </div>
            </motion.div>
          )}

          {activeDevice === "desktop" && (
            <motion.div
              key="desktop-device"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.3 }}
              className="w-full max-w-6xl h-[780px] bg-[#050505] rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.9)] border border-white/10 flex flex-col overflow-hidden"
              id="desktop-frame-container"
            >
              {/* Simulated Browser Chrome */}
              <div className="w-full bg-[#050505] px-5 py-3.5 border-b border-white/10 flex items-center justify-between gap-4 select-none">
                <div className="flex items-center gap-1.5">
                  <div className="w-2.5 h-2.5 rounded-full bg-white/10" />
                  <div className="w-2.5 h-2.5 rounded-full bg-white/10" />
                  <div className="w-2.5 h-2.5 rounded-full bg-white/10" />
                </div>
                {/* Search / Address bar */}
                <div className="flex-1 max-w-xl bg-white/5 border border-white/10 text-white/40 rounded-full px-4 py-1 text-[11px] font-mono tracking-wide flex items-center gap-1.5">
                  <span className="text-white/30 select-none">https</span>
                  <span className="text-white/20">://</span>
                  <span className="text-white/80">gallery.sophisticated.dark</span>
                </div>
                {/* Dummy layout stats */}
                <div className="flex items-center gap-2 text-[10px] text-white/30 font-mono tracking-widest uppercase">
                  <span>SSL ACTIVE</span>
                  <span className="w-1.5 h-1.5 rounded-full bg-white/40" />
                </div>
              </div>

              {/* Inside App Space */}
              <div className="flex-1 w-full bg-[#050505] overflow-hidden flex flex-col relative select-text">

                {children}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}
