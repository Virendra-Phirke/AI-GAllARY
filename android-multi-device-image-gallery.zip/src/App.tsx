/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import DeviceSimulator from "./components/DeviceSimulator";
import GalleryApp from "./components/GalleryApp";
import { DeviceType } from "./types";

export default function App() {
  const [activeDevice, setActiveDevice] = useState<DeviceType>("phone");
  const [isNativelyMobile, setIsNativelyMobile] = useState<boolean>(false);

  useEffect(() => {
    const handleResize = () => {
      const width = window.innerWidth;
      const isMobile = width <= 768;
      setIsNativelyMobile(isMobile);
      
      if (isMobile) {
        setActiveDevice("phone");
      }
    };
    
    // Initial check
    handleResize();
    
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  if (isNativelyMobile) {
    return (
      <div className="w-full h-[100dvh] bg-[#050505] text-[#E0D8D0] font-sans overflow-hidden flex flex-col relative" id="native-mobile-root">
        <GalleryApp deviceMode="phone" />
      </div>
    );
  }

  return (
    <DeviceSimulator activeDevice={activeDevice} setActiveDevice={setActiveDevice}>
      <GalleryApp deviceMode={activeDevice} />
    </DeviceSimulator>
  );
}
